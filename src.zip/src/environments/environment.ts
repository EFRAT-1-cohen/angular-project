export const environment = {
  production: true,
  apiUrl: 'https://team-tasks-api-ako5.onrender.com'
};